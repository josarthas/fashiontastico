<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sketchy</title>
	
	<link rel="shortcut icon" href="favicon.ico"/>

    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Schoolbell:regular"/>

	<link rel="stylesheet" type="text/css" href="css/main.css"/>
    <link rel="stylesheet" type="text/css" href="css/layout.css"/>
	<link rel="stylesheet" type="text/css" href="css/ui-darkness/jquery-ui-1.8.10.custom.css"/>
    <link rel="stylesheet" type="text/css" href="css/colorpicker.css"/>
	
	<script type="text/javascript" src="js/jquery/jquery-1.4.4.min.js"></script>
	<script type="text/javascript" src="js/jquery/jquery-ui-1.8.10.custom.min.js"></script>
    <script type="text/javascript" src="js/rxjs/rx.js"></script>
    <script type="text/javascript" src="js/rxjs/rx.jQuery.js"></script>
	<script type="text/javascript" src="js/mootools/mootools-core-compressed-1.3.js"></script>
	<script type="text/javascript" src="js/mootools/mootools-more-compressed-1.3.js"></script>
    <script type="text/javascript" src="js/modernizr/modernizr-1.6.min.js"></script>
    <script type="text/javascript" src="js/colorpicker/colorpicker.js"></script>
    <script type="text/javascript" src="js/layout.js"></script>
    <script type="text/javascript" src="js/brushes.js"></script>
    <script type="text/javascript" src="js/canvas.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            // display a warning message if canvas is not supported
            if (!Modernizr.canvas) {
                $("#message").html("<p><b>WARNING</b>: Your browser does not support HTML5's canvas feature, you won't be able to see the drawings below</p>");
                $("article").hide();
            } else {
                initialize();
            }

            function initialize() {
                var imagesLoaded = $(document).toObservable("images-loaded");
                var cursorsLoaded = $(document).toObservable("cursors-loaded");

                // fade out the splash panel when images and cursors are loaded
                imagesLoaded
                    .Zip(cursorsLoaded, function (left, right) { return right; })
                    .Delay(1000)
                    .Subscribe(function () {
                        $("#splash").fadeOut("slow");
                    });

                // initialize the canvas
                initializeCanvas();

                // load the images
                loadImages();                
            }

            function loadImages() {
                var images = ["images/tools_panel_colour_picker_button.png",
                              "images/tools_panel_delete_button.png",
                              "images/tools_panel_eraser_button.png",
                              "images/tools_panel_paint_button.png",
                              "images/tools_panel_pencil_button.png",
                              "images/tools_panel_spray_button.png"],
                    cursors = ["cursors/colour_picker_cursor.cur",
                               "cursors/eraser_cursor.cur",
                               "cursors/paint_cursor.cur",
                               "cursors/pencil_cursor.cur",
                               "cursors/spray_cursor.cur"];

                // fire the images-loaded event when all images are loaded
                Asset.images(images, {
                    onComplete: function () {
                        $(document).trigger("images-loaded");
                    }
                });

                // fire the cursors-loaded event when all cursors are loaded
                Asset.images(cursors, {
                    onComplete: function () {
                        $(document).trigger("cursors-loaded");
                    }
                });
            }
        });
    </script>
</head>
<body>
    <div id="menu">
										<ul>
											<li><a href="../index.php">Pagina principal</a></li>
											
										</ul>
    </div>
    <div id="wrapper">
        <aside id="message"></aside>

        <div id="splash">
            <p>Loading...</p>
            <img src="images/ajax-loader.gif" />
        </div>

        <div id="accordion">
            <h2 id="step-1"><a href="#">Paso 1 - Crear</a></h2>
            <div>
                <div id="canvas-panel" class="block">
                    <canvas id="drawingCanvas" width="700" height="450"></canvas>
			        <canvas id="overlay" width="700" height="450"
                            onSelectStart="setCursor(this); return false;"></canvas>
                </div>

                <div id="tools-panel" class="block">
                    <ul>
                        <li class="tool-panel-button tool-button">
                            <div id="stroke-colour-tool" class="block, fill">
                                <p>Colour</p>
                                <span id="stroke-colour"></span>
                                <div id="stroke-colour-picker"></div>
                            </div>                            
                        </li>
                        <li class="tool-panel-button tool-button selected">
                            <img id="pencil-tool" src="images/tools_panel_pencil_button.png" class="block, fill" />
                        </li>
                        <li class="tool-panel-button tool-button">
                            <img id="spray-tool" src="images/tools_panel_spray_button.png" class="block, fill" />
                        </li>
                        <li class="tool-panel-button tool-button">
                            <img id="paint-tool" src="images/tools_panel_paint_button.png" class="block, fill" />
                        </li>
                        <li class="tool-panel-button tool-button">
                            <img id="colour-picker-tool" src="images/tools_panel_colour_picker_button.png" class="block, fill" />
                        </li>
                        <li class="tool-panel-button tool-button">
                            <img id="eraser-tool" src="images/tools_panel_eraser_button.png" class="block, fill" />
                        </li>
                        <li class="tool-panel-button tool-button">
                            <img id="delete-tool" src="images/tools_panel_delete_button.png" class="block, fill" />
                        </li>
                    </ul>
                </div>
            </div>
			
            <h2 id="step-2"><a href="#">Paso 2 - Guardar</a></h2>
            <div>
                <h2>Clic derecho para guardar:</h2>
                <img id="output-img" />
            </div>
        </div>
    </div>
</body>
</html>