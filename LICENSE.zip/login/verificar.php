<?php
session_start();
include "../conexion.php";
$re=mysqli_query($con,"select * from usuarios where Usuario='".$_POST['Usuario']."' AND 
 					Password='".$_POST['Password']."'")	or die(mysql_error());
	while ($f=mysqli_fetch_array($re)) {
		$arreglo[]=array('Nombre'=>$f['Nombre'],
			'Apellido'=>$f['Apellido'],'Imagen'=>$f['Imagen']);
	}
	if(isset($arreglo)){
		$_SESSION['Usuario']=$arreglo;
		header("Location: ../admin.php");
	}else{
		header("Location: ../login.php?error=datos no validos");
	}
?>
<?php
 $sql = "INSERT INTO usuarios(Nombre,Password,Usuario) ".
     "VALUES ('$nombre', '$direccion', '$telefono', '$email')";
   $result = mysql_query($sql);
   echo "¡Gracias! Hemos recibido sus datos.\n"; 
?>